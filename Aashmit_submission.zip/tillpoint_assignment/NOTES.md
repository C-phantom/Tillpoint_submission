# NOTES

Fill in every field below before you submit. We read this file first: a submission with an empty field is not graded.
Write in your own words. If you did not fix something, set Status to `not fixed` and say what you found and tried; that still counts.
Status is one of: `fixed`, `partly fixed`, `not fixed`. Commits: the short hashes of the commits for this item, or `none`.

## 1. Report

> Finance says that on some days the revenue in the daily report is higher than what the payment provider paid out, and a few orders show more money received than their total.

**Status:** fixed

**What I saw:** The daily report summed every payment row, so replayed webhook deliveries counted the same payment more than once. A provider payment larger than the order total could also make both the order's paid amount and report revenue exceed the order total.

**Root cause:** `payments` did not enforce a unique event ID, and `paid_cents()` summed the full provider amount without comparing it with the order total.

**Fix and why:** Added a unique event ID index and transactionally check for repeated events before inserting anything. A payment is now accepted only up to the amount remaining on the order, and separate payments arriving after an order is paid or shipped are ignored. The report also caps received amounts to the order total and the startup migration removes older duplicate event rows. This keeps both provider retries and genuine late payments from inflating the books.

**How I verified it:** Added tests for repeated delivery, an overpayment, and late separate payment. Before the fix, the original code counted repeated and extra payments. The same tests now return 1200 for those settled cases. The full suite passes.

**Commits:** `77a59fc`

## 2. Report

> Products show as sold out, or nearly, while the shelf is full. Staff say it gets worse on days when many customers abandon checkout.

**Status:** fixed

**What I saw:** Cancelling an unpaid order left the reserved units deducted from stock. There was also a race when two connections checked and reserved the last unit.

**Root cause:** `Orders.cancel()` restocked only paid orders, so pending reservations remained held. `Catalog.reserve()` checked a cached stock value and then issued an unrestricted subtraction, allowing concurrent connections to both pass the same check.

**Fix and why:** Pending and paid cancellations now release stock. Reservation now uses one conditional SQL update (`stock >= qty`) and returns `OutOfStock` based on the current database value if the update does not succeed. This makes the stock check and subtraction atomic for separate server connections.

**How I verified it:** Tested pending cancellation and a two-connection race for the final unit. After the fix one reservation succeeds and the other gets `OutOfStock`; stock remains zero rather than going negative.

**Commits:** `c41ecec`

## 3. Report

> Customers in taxed regions who used a coupon say the tax on their receipt is too high. Receipts without a coupon are right.

**Status:** fixed

**What I saw:** The tax for a taxed-region order with a percentage coupon was calculated from the pre-discount subtotal.

**Root cause:** `price_order()` calculated tax before applying `discount_for()`.

**Fix and why:** The discount is now calculated first and tax is calculated against `subtotal - discount`. Receipts without coupons are unchanged because their taxable amount is still the full subtotal.

**How I verified it:** Added a CA-order test with a 10% coupon: subtotal 1200, discount 120, tax 78, total 1158. It failed as 87 tax cents before the change and passes now.

**Commits:** `06a777f`

## 4. Report

> Our shop in India (UTC+5:30) says sales taken in the morning do not appear in that day's report and turn up under the day before.

**Status:** fixed

**What I saw:** With UTC+5:30 configured, a payment at 19:00 UTC on March 9 was placed outside the March 10 India day instead of at 00:30 India time.

**Root cause:** `day_bounds_utc()` added the shop offset, but converting a local day to UTC requires subtracting the offset.

**Fix and why:** Changed the calculation to use local midnight minus `utc_offset_minutes`. A UTC+5:30 day now starts at 18:30 UTC on the previous date.

**How I verified it:** Added a test for 19:00 UTC on March 9 with an offset of 330 minutes. It is counted on March 10 and not on March 9. The full suite passes.

**Commits:** `a6820f0`

## 5. Report

> Ever since we started running two server workers, we have sold more units of an item than we had, and its stock went negative.

**Status:** fixed

**What I saw:** The stock result depended on which connection read stock first. Two workers could pass the stock check and decrement the same unit.

**Root cause:** The catalog cached stock and reservation used a read followed by a separate update. A stale cache could allow both connections to believe stock was available.

**Fix and why:** Reservation now uses an atomic SQL conditional update with no cached stock value as the gate. SQLite serializes the update, and only the connection whose update changes a row reserves the unit.

**How I verified it:** Ran the final unit for stock against two SQLite connections. It passes: exactly one reserves the final unit and the other receives `OutOfStock`.

**Commits:** `c41ecec`

## 6. Open question

> Open question from support, no single right answer: sometimes a customer really does pay twice for one order (two separate payments, not a retry of the same one). Today the system records both and says nothing. Decide what should happen, build the smallest version of your decision, and explain what it costs in `NOTES.md`.

**My decision:** Accept payment event deliveries once, cap accepted funds at the order total, and ignore a different payment event if the order is already paid or shipped.

**Why:** This avoids recording extra funds as settled revenue and makes provider retries safe. It also leaves the order in a usable paid state without adding a second payment row. A real overpayment still needs provider-side handling, but the application should not call the extra money revenue.

**What it costs:** It is only a small application-side guard. There is no automatic provider refund, so support or finance would have to refund the extra amount with the payment provider. It also means a genuinely under-funded split payment is accepted in parts until the total is reached.

**What I built:** A unique event index, transaction checks for existing event IDs, remaining-balance capping, and paid/shipped state checks. Existing duplicate event rows are removed by the database migration, and daily sales caps received funds at order totals.

**How I verified it:** Tests cover provider retry, partial settlement, one overpayment, and a separate payment after the order is already paid.

**Commits:** `77a59fc`, `c41ecec`

## Other things I noticed

Problems outside the reports: what, where, and whether you fixed them. Write `none` if there were none.

none

## Session logs

Which AI tools you used, and one line per file in `session_logs/`.

Copilot SDK in VS Code was used for repository investigation, implementation, testing, commit creation, and documentation. `session_logs/copilot_sdk_session.md` contains the session record.
