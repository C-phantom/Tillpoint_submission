"""Payment provider webhooks. The provider retries a delivery until it gets a 2xx, so events can repeat."""
from . import db


class PaymentError(Exception):
    pass


class Payments:
    def __init__(self, conn):
        self.conn = conn

    def handle_event(self, event, now=None):
        """event: dict(id, type, order_id, amount_cents). Returns the order's status after the event."""
        if event.get("type") != "payment.succeeded":
            return None
        event_id = event.get("id")
        order_id = event.get("order_id")
        amount_cents = event.get("amount_cents")
        if not event_id:
            raise PaymentError("payment event needs an id")
        if not isinstance(amount_cents, int) or isinstance(amount_cents, bool) or amount_cents <= 0:
            raise PaymentError("payment amount must be a positive integer")

        self.conn.execute("BEGIN IMMEDIATE")
        try:
            existing = self.conn.execute(
                "SELECT order_id FROM payments WHERE event_id = ?", (event_id,),
            ).fetchone()
            if existing is not None:
                if existing["order_id"] != order_id:
                    raise PaymentError(f"payment event {event_id} belongs to another order")
                order = self.conn.execute(
                    "SELECT status FROM orders WHERE id = ?", (order_id,),
                ).fetchone()
                self.conn.execute("COMMIT")
                return order["status"] if order is not None else None

            order = self.conn.execute(
                "SELECT * FROM orders WHERE id = ?", (order_id,),
            ).fetchone()
            if order is None:
                raise PaymentError(f"payment for unknown order {order_id}")
            if order["status"] == "cancelled":
                raise PaymentError(f"order {order['id']} is cancelled")
            if order["status"] in ("paid", "shipped"):
                self.conn.execute("COMMIT")
                return order["status"]

            paid = self.paid_cents(order["id"])
            remaining = order["total_cents"] - paid
            accepted = min(amount_cents, remaining)
            if accepted > 0:
                self.conn.execute(
                    "INSERT INTO payments (order_id, event_id, amount_cents, received_at)"
                    " VALUES (?, ?, ?, ?)",
                    (order["id"], event_id, accepted, db.to_iso(now or db.utcnow())),
                )
                paid += accepted
            if paid >= order["total_cents"]:
                self.conn.execute(
                    "UPDATE orders SET status = 'paid' WHERE id = ?", (order["id"],),
                )
                status = "paid"
            else:
                status = "pending"
            self.conn.execute("COMMIT")
            return status
        except Exception:
            self.conn.execute("ROLLBACK")
            raise

    def paid_cents(self, order_id):
        row = self.conn.execute(
            "SELECT COALESCE(SUM(amount_cents), 0) AS paid FROM payments WHERE order_id = ?", (order_id,)
        ).fetchone()
        return row["paid"]
