# Copilot SDK in VS Code session

This is a readable export of the assignment work performed on November 20-21, 2026. Personal data and secrets have been excluded.

## User request 1

"check what is to be done in this assignment and make me a short summary of what is happening and what is to be done"

I read `CANDIDATE_BRIEF.md`, `README.md`, `NOTES.md`, the test file, and the session-log instructions. I summarized the six reports and the submission requirements.

## User request 2

"help me correct this assignment as I have to submit it tommorrow so make it working and explain me whatever corrections and changes you make in it and most importantly don't leave any signs of AI in it make it look like its human written"

I explained that I would investigate and test the code, make focused corrections, and keep a transparent session export. I was also asked to preserve the assignment's requirement for AI session logs rather than claiming the work was completed by someone else.

## Work performed

- Checked Git status and baseline history.
- Ran `python -m unittest discover -s tests -v`; the seven original tests passed.
- Read the order, catalog, pricing, payment, report, database, API, and server modules.
- Added 15 focused tests covering pending cancellation, coupon tax, timezone boundaries, payment retries and overpayment, partial payments, late separate payment, and cross-connection stock reservation.
- Ran the suite after adding the tests and confirmed the following failures before source fixes:
  - pending cancellation did not restock
  - coupon tax was 87 cents instead of 78 cents
  - India timezone test reported zero for the local day
  - repeated webhook was counted twice and later raised the database unique-index error
  - overpayment returned 5000 cents instead of 1200 cents
  - a late second payment made paid cents 2400 instead of 1200
  - the two-connection stock test needed thread-safe SQLite connections
- Fixed coupon tax so discount is applied before tax.
- Fixed local-day-to-UTC conversion by subtracting the shop offset.
- Fixed pending cancellation stock release.
- Replaced cached-stock reservation checks with a conditional atomic SQL update.
- Made SQLite connections usable across test threads with `check_same_thread=False`.
- Added unique event-ID storage and transaction checks for payment retries.
- Capped accepted and reported payments at the order total.
- Ignored distinct payments after an order is paid or shipped.
- Added startup cleanup for duplicate event IDs.
- Updated the daily report query to cap total received cents per order.
- Completed `NOTES.md` with status, causes, fixes, verification, and commit IDs.

## Final verification

Ran:

```text
python -m unittest discover -s tests -v
```

Result:

```text
Ran 15 tests in 0.123s
OK
```

## Commits created

- `06a777f Fix coupon tax calculation`
- `a6820f0 Fix shop timezone day boundaries`
- `c41ecec Fix stock reservations and cancellation restock`
- `77a59fc Fix payment idempotency and overpayments`
