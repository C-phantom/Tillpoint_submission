import unittest
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor
import tempfile
import os
import threading

from tillpoint import db, reports
from tillpoint.api import App
from tillpoint.catalog import Catalog, OutOfStock


class OrderDeskTest(unittest.TestCase):
    def setUp(self):
        self.conn = db.connect()
        self.app = App(self.conn)
        self.app.catalog.add_product("MUG", "Mug", 1200, stock=10)
        self.app.catalog.add_product("TEE", "T-shirt", 2500, stock=3)
        self.conn.execute("INSERT INTO coupons (code, kind, value) VALUES ('TEN', 'percent', 10)")

    def tearDown(self):
        self.conn.close()

    def test_order_totals_with_tax(self):
        order = self.app.orders.create("ana", [("MUG", 2), ("TEE", 1)], region="CA")
        self.assertEqual(order["subtotal_cents"], 4900)
        self.assertEqual(order["tax_cents"], 355)
        self.assertEqual(order["total_cents"], 5255)
        self.assertEqual(self.app.catalog.get_product("MUG").stock, 8)

    def test_coupon_takes_ten_percent(self):
        order = self.app.orders.create("ana", [("MUG", 1)], coupon_code="TEN")
        self.assertEqual(order["discount_cents"], 120)
        self.assertEqual(order["total_cents"], 1080)

    def test_coupon_discount_is_removed_before_tax(self):
        order = self.app.orders.create("ana", [("MUG", 1)], region="CA", coupon_code="TEN")
        self.assertEqual(order["subtotal_cents"], 1200)
        self.assertEqual(order["discount_cents"], 120)
        self.assertEqual(order["tax_cents"], 78)
        self.assertEqual(order["total_cents"], 1158)

    def test_out_of_stock(self):
        with self.assertRaises(OutOfStock):
            self.app.orders.create("ana", [("TEE", 4)])
        self.assertEqual(self.app.catalog.get_product("TEE").stock, 3)

    def test_payment_marks_order_paid(self):
        order = self.app.orders.create("ana", [("MUG", 1)])
        status, payload = self.app.handle("POST", "/webhooks/payments", {
            "id": "evt_1", "type": "payment.succeeded", "order_id": order["id"], "amount_cents": 1200})
        self.assertEqual((status, payload["status"]), (200, "paid"))

    def test_cancel_paid_order_restocks(self):
        order = self.app.orders.create("ana", [("TEE", 2)])
        self.app.payments.handle_event(
            {"id": "evt_2", "type": "payment.succeeded", "order_id": order["id"], "amount_cents": 5000})
        self.app.orders.cancel(order["id"])
        self.assertEqual(self.app.catalog.get_product("TEE").stock, 3)

    def test_cancel_pending_order_restocks(self):
        order = self.app.orders.create("ana", [("TEE", 2)])
        self.app.orders.cancel(order["id"])
        self.assertEqual(order["status"], "pending")
        self.assertEqual(self.app.catalog.get_product("TEE").stock, 3)

    def test_daily_sales(self):
        order = self.app.orders.create("ana", [("MUG", 1)])
        noon = datetime(2025, 3, 10, 12, 0, tzinfo=timezone.utc)
        self.app.payments.handle_event(
            {"id": "evt_3", "type": "payment.succeeded", "order_id": order["id"], "amount_cents": 1200}, now=noon)
        self.assertEqual(reports.daily_sales(self.conn, "2025-03-10"),
                         {"day": "2025-03-10", "revenue_cents": 1200, "orders": 1})

    def test_daily_sales_uses_shop_timezone_offset(self):
        order = self.app.orders.create("ana", [("MUG", 1)])
        first_morning = datetime(2025, 3, 9, 19, 0, tzinfo=timezone.utc)
        self.app.payments.handle_event(
            {"id": "evt_timezone", "type": "payment.succeeded",
             "order_id": order["id"], "amount_cents": 1200},
            now=first_morning,
        )
        self.assertEqual(
            reports.daily_sales(self.conn, "2025-03-10", utc_offset_minutes=330)["revenue_cents"],
            1200,
        )
        self.assertEqual(
            reports.daily_sales(self.conn, "2025-03-09", utc_offset_minutes=330)["revenue_cents"],
            0,
        )

    def test_price_change(self):
        self.app.handle("PUT", "/products/MUG", {"price_cents": 1500})
        self.assertEqual(self.app.catalog.get_product("MUG").price_cents, 1500)

    def test_repeated_webhook_is_not_counted_twice(self):
        order = self.app.orders.create("ana", [("MUG", 1)])
        event = {"id": "evt_repeat", "type": "payment.succeeded",
                 "order_id": order["id"], "amount_cents": 1200}
        self.app.payments.handle_event(event)
        self.app.payments.handle_event(event)
        self.assertEqual(self.app.payments.paid_cents(order["id"]), 1200)

    def test_overpayment_is_capped_at_order_total(self):
        order = self.app.orders.create("ana", [("MUG", 1)])
        self.app.payments.handle_event({
            "id": "evt_overpay", "type": "payment.succeeded",
            "order_id": order["id"], "amount_cents": 5000,
        })
        self.assertEqual(self.app.payments.paid_cents(order["id"]), 1200)
        self.assertEqual(reports.daily_sales(self.conn, datetime.now(timezone.utc).strftime("%Y-%m-%d"))[
            "revenue_cents"], 1200)

    def test_separate_late_payment_is_ignored_after_paid(self):
        order = self.app.orders.create("ana", [("MUG", 1)])
        self.app.payments.handle_event({
            "id": "evt_paid", "type": "payment.succeeded",
            "order_id": order["id"], "amount_cents": 1200,
        })
        status = self.app.payments.handle_event({
            "id": "evt_second_payment", "type": "payment.succeeded",
            "order_id": order["id"], "amount_cents": 1200,
        })
        self.assertEqual(status, "paid")
        self.assertEqual(self.app.payments.paid_cents(order["id"]), 1200)

    def test_partial_payments_settle_once(self):
        order = self.app.orders.create("ana", [("MUG", 1)])
        first = self.app.payments.handle_event({
            "id": "evt_partial_1", "type": "payment.succeeded",
            "order_id": order["id"], "amount_cents": 700,
        })
        second = self.app.payments.handle_event({
            "id": "evt_partial_2", "type": "payment.succeeded",
            "order_id": order["id"], "amount_cents": 1000,
        })
        self.assertEqual(first, "pending")
        self.assertEqual(second, "paid")
        self.assertEqual(self.app.payments.paid_cents(order["id"]), 1200)

    def test_two_connections_cannot_reserve_last_unit(self):
        fd, path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        try:
            conn1 = db.connect(path)
            conn2 = db.connect(path)
            catalog1 = Catalog(conn1)
            catalog2 = Catalog(conn2)
            catalog1.add_product("ONE", "One", 100, stock=1)
            barrier = threading.Barrier(2)

            def reserve(catalog):
                barrier.wait()
                try:
                    catalog.reserve("ONE", 1)
                    return "reserved"
                except OutOfStock:
                    return "sold-out"

            with ThreadPoolExecutor(max_workers=2) as pool:
                results = list(pool.map(reserve, (catalog1, catalog2)))

            self.assertEqual(sorted(results), ["reserved", "sold-out"])
            self.assertEqual(catalog1.get_product("ONE").stock, 0)
        finally:
            if "conn1" in locals():
                conn1.close()
            if "conn2" in locals():
                conn2.close()
            os.remove(path)


if __name__ == "__main__":
    unittest.main()
